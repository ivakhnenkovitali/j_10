public enum Discount {
    UNDISCOUNTED(1.0),
    DISCOUNTED(0.9),
    REDDISCOUTED(0.75);

    //дополнительное поле для каждого элемента перечисления
    private double discount;

    Discount(double discount) {
        this.discount = discount;
    }

    //можно сгенерировать сеттер для изменения поля
    //также в перечислении можно создавать дополнитьльные метода
    //как нестатические так и статические

    public double getDiscount() {
        return discount;
    }

    @Override
    public String toString() {
        return "Discount{" +
                "name='" + name() + '\'' +
                ", discount=" + discount +
                '}';
    }
}
