package model;

public class Earrings extends Jewellery {
    private static double earringDifficultFactor = 1.5;

    public Earrings() {
    }

    public Earrings(int article, Producer producer, double weight, Material material) {
        super(article, producer, weight, material);
    }

    @Override
    public double getDifficultFactor() {
        return earringDifficultFactor;
    }

    @Override
    public String toString() {
        return "Earrings{" +
                "article=" + getArticle() +
                ", producer=" + getProducer() +
                ", weight=" + getWeight() +
                ", material=" + getMaterial() +
                ", calculatePrice=" + calculatePrice() +
                '}';
    }
}
