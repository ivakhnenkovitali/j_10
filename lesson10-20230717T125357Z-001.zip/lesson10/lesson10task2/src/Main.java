public class Main {
    public static void main(String[] args) {
        for (Discount value : Discount.values()) {
            System.out.println(value);
        }

        double x = Discount.DISCOUNTED.getDiscount();
        System.out.println(x);

        System.out.println("--------------------");

        for (AbstractDiscount value : AbstractDiscount.values()) {
            System.out.println(value.discount());
        }

        //количество элементов перечисления
        System.out.println(AbstractDiscount.values().length);
    }
}
