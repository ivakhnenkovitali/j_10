package model;

public enum Material {
    GOLD(110, "золото"),
    SILVER(15, "серебро"),
    WHITE_GOLD(130,"белое золото");

    private double pricePerGram;
    private String rusTitle;

    Material(double pricePerGram, String rusTitle) {
        this.pricePerGram = pricePerGram;
        this.rusTitle = rusTitle;
    }

    public double getPricePerGram() {
        return pricePerGram;
    }

    @Override
    public String toString() {
        return "Material{" +
                "name='" + name() + '\'' +
                ", pricePerGram=" + pricePerGram +
                ", rusTitle='" + rusTitle + '\'' +
                '}';
    }
}
