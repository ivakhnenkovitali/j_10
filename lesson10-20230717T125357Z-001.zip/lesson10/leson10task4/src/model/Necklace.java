package model;

public class Necklace extends Jewellery {
    private static double necklaceDifficultFactor = 1.4;

    public Necklace() {
    }

    public Necklace(int article, Producer producer, double weight, Material material) {
        super(article, producer, weight, material);
    }

    @Override
    public double getDifficultFactor() {
        return necklaceDifficultFactor;
    }

    @Override
    public String toString() {
        return "Necklace{" +
                "article=" + getArticle() +
                ", producer=" + getProducer() +
                ", weight=" + getWeight() +
                ", material=" + getMaterial() +
                ", calculatePrice=" + calculatePrice() +
                '}';
    }
}
