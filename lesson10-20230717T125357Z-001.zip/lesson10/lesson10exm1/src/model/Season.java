package model;

//enum - необычного рода класс, который наследует
//не у Object, а у класса Enum

//Перечисления возволяют объединить набор логически связынных
//между собой именованных констант

public enum Season {
    WINTER,//public static final Season WINTER = new Season("WINTER", 0);
    SPRING,
    SUMMER,
    FALL
}
