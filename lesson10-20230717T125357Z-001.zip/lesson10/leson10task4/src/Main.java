import model.*;

public class Main {
    public static void main(String[] args) {

        Producer[] producers={
                new Producer("SLAVIA"),
                new Producer("CRISTAL"),
                new Producer("SOKOLOV")
        };

        Jewellery[] jewelleries = {
                new Ring(123, producers[0], 3, Material.GOLD, 17),
                new Earrings(234, producers[1], 5, Material.SILVER),
                new Necklace(741, producers[2], 2, Material.WHITE_GOLD)
        };

        for (Jewellery jewellery : jewelleries) {
            System.out.println(jewellery);
        }

    }
}
