package model;

public class Ring extends Jewellery{
    private static double ringDifficultFactor = 1.2;
    private double size;

    public Ring() {
    }

    public Ring(int article, Producer producer, double weight, Material material, double size) {
        super(article, producer, weight, material);
        this.size = size;
    }

    public double getSize() {
        return size;
    }

    public void setSize(double size) {
        this.size = size;
    }

    @Override
    public double getDifficultFactor() {
        return ringDifficultFactor;
    }

    @Override
    public String toString() {
        return "Ring{" +
                "article=" + getArticle() +
                ", producer=" + getProducer() +
                ", weight=" + getWeight() +
                ", material=" + getMaterial() +
                ", size=" + size +
                ", calculatePrice=" + calculatePrice() +
                '}';
    }
}
